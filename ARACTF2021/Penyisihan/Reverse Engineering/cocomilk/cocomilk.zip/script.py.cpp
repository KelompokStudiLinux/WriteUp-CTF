#if 0
""" "
#endif
#include <iostream>
#include <string>
#include <bits/stdc++.h> 
using namespace std;
string z(string a);string y(string b);
int main() {string a;cout<<"Input: ";cin>>a;
#if 0
" """
#endif
#if 0
a = input("Input: ")
b = ""
c = ""
#endif
#if 0
""" "
#endif
cout << z(a) << endl;
return 0;
}
#if 0
" """
#endif
#if 0
for x, y in enumerate(a):
    if x % 2 == 0:
#endif
#if 0
        """ "
#endif
string z(string a) {string b = "";
for (int i = 0; i < a.length(); i+=2) {b += a[i];
#if 0
        " """
#endif
#if 0
        b += y
    else :
        c += y
#endif
#if 0
""" "
#endif
}return y(b);}
string y(string b) {string a = "";
for (int i = 0;i < b.length(); i++) {a+=b[i]^i;
#if 0
" """
#endif
#if 0
c = c[::-1]
d = ""
for y,z in enumerate(c):
#endif
#if 0
    """ "
#endif
}
reverse(a.begin(), a.end());
return a;
}
#if 0
    " """
#endif
#if 0
    d += chr(ord(z)^y^ord(b[y]))
print(":".join("{:02x}".format(ord(c)) for c in d))
#endif