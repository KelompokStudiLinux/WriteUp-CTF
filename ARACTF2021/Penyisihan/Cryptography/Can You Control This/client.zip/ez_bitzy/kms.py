from interfaces import TokenProvider, RandomnessProvider


class KMS:
    def __init__(self, tp: TokenProvider,rp: RandomnessProvider):
        self.key_size = tp.get_key_size()
        self.tp = tp
        self.rp = rp

    def import_key(self, key: bytes) -> bytes:
        assert len(key) == self.key_size, "invalid key size"
        return self.tp.generate_key_usage_token(key)

    def generate_key(self) -> bytes:
        key = self.rp.get_random_bytes(self.key_size)
        return self.tp.generate_key_usage_token(key)

    def encrypt(self, token: bytes, plaintext: bytes) -> bytes:
        key = self.tp.extract_key_from_token(token)
        return self.tp.encrypt_plaintext(key, plaintext)

    def is_valid(self, token: bytes, key: bytes) -> bool:
        return self.tp.extract_key_from_token(token) == key
