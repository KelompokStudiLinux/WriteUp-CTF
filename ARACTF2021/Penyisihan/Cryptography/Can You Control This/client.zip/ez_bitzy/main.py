import json
from kms import KMS
from providers.token.aes256_cbc import Aes256CbcTP
from providers.randomness.mersenne import MersenneTwisterRP

def main():
    rp = MersenneTwisterRP()

    tp = Aes256CbcTP(rp)
    
    kms = KMS(tp, rp)

    req_lim = 1002  # the limit number of requests
    key_imp_lim = 1  # the limit number of imported keys
    target = bytes.fromhex( "2021" * (kms.key_size // 2))  # the token forgery target
    keys_imported = 0
    for _ in range(req_lim):
        try:
            req = json.loads(input("Payload : "))
            if req["action"] == "import_key":
                key = bytes.fromhex(req["key"])
                assert keys_imported < key_imp_lim, "cannot import more keys"
                assert key != target, "cannot import this key"
                token = kms.import_key(key)
                print(json.dumps({
                    "token": token.hex()
                }))
                keys_imported += 1

            elif req["action"] == "generate_key":
                token = kms.generate_key()
                print(json.dumps({
                    "token": token.hex()
                }))

            elif req["action"] == "encrypt":
                token = bytes.fromhex(req["token"])
                plaintext = bytes.fromhex(req["plaintext"])
                ciphertext = kms.encrypt(token, plaintext)
                print(json.dumps({
                    "ciphertext": ciphertext.hex()
                }))

            elif req["action"] == "decrypt":
                print(json.dumps({
                    "error":"Sorry this method is not implemented yet"
                }))

            elif req["action"] == "getSecondFlag":
                token = bytes.fromhex(req["token"])
                assert kms.is_valid(token, target), "invalid token"
                with open("flag2", "rb") as f:
                    flag2 = int.from_bytes(f.read(), "big")
                print(json.dumps({"flag2": flag2}))

            else:
                assert False, "invalid action"

        except Exception as err:
            print(json.dumps({"error": str(err)}))


if __name__ == '__main__':
    main()
