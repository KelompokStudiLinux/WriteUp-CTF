from interfaces import RandomnessProvider
import random
import os


class MersenneTwisterRP(RandomnessProvider):
    """A randomness provider implementation using the Mersenne Twister
    algorithm. In fact, this is just a wrap of Python's random module."""

    def __init__(self):
        self.rand = random.Random(os.urandom(32))

    def get_random_bytes(self, size: int) -> bytes:
        return self.rand.getrandbits(8 * size).to_bytes(size, "big")
