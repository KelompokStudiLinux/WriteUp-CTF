from interfaces import RandomnessProvider, TokenProvider
from Crypto.Util.Padding import pad, unpad
from Crypto.Cipher.AES import MODE_CBC
from Crypto.Cipher.AES import new as AesCipher
from Crypto.Cipher import AES
from Crypto.Util import Counter
import zlib

class Aes256CbcTP(TokenProvider):
    """A token provider implementation using AES256/CBC algorithm."""

    def __init__(self, rp: RandomnessProvider):
        self.rp = rp
        self.secret = rp.get_random_bytes(32)
        f = open("flag1","r")
        self.flag1 = f.read()

    def get_key_size(self) -> int:
        return 32

    def get_token_size(self) -> int:
        return (
                + 16  # iv
                + (32 + 16)  # encrypted of (key + pad)
        )

    def encrypt_plaintext(self, key: bytes, plaintext:bytes) -> bytes:
        iv = int.from_bytes(self.rp.get_random_bytes(16),'big')
        cipher = AES.new(key, AES.MODE_CTR, counter=Counter.new(128, initial_value=iv))
        return cipher.encrypt(zlib.compress(plaintext + self.flag1.encode()))

    def generate_key_usage_token(self, key: bytes) -> bytes:
        assert len(key) == self.get_key_size(), "unsupported key size"
        iv = self.rp.get_random_bytes(16)
        cipher = AesCipher(self.secret, MODE_CBC, iv)
        return cipher.encrypt(pad(key, 16))+iv

    def extract_key_from_token(self, token: bytes) -> bytes:
        assert len(token) == self.get_token_size(), "invalid token"
        iv = token[-16:]
        ciphertext = token[:-16]
        cipher = AesCipher(self.secret, MODE_CBC, iv)
        return unpad(cipher.decrypt(ciphertext), 16)
