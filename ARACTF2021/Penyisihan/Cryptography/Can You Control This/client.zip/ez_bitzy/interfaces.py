from abc import ABC, abstractmethod


class TokenProvider(ABC):
    """Interface for a token service provider."""

    @abstractmethod
    def get_key_size(self) -> int:
        pass

    @abstractmethod
    def get_token_size(self) -> int:
        pass

    @abstractmethod
    def generate_key_usage_token(self, key: bytes) -> bytes:
        pass

    @abstractmethod
    def extract_key_from_token(self, token: bytes) -> bytes:
        pass

class RandomnessProvider:
    """Interface for a randomness service provider."""

    @abstractmethod
    def get_random_bytes(self, size: int) -> bytes:
        pass
