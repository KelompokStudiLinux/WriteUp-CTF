from django.apps import AppConfig


class MathgameConfig(AppConfig):
    name = 'mathgame'
